/** Automatically generated file. DO NOT MODIFY */
package cc.lifelink.cn;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}